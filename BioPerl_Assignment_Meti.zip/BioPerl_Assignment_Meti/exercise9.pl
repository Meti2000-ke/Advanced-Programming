#!/usr/bin/perl

use strict;
use warnings;
use Bio::DB::EUtilities;
use Bio::SeqIO;
use IO::String;

# Retrieve the GenBank record
my $factory = Bio::DB::EUtilities->new(
    -eutil   => 'efetch',
    -db      => 'nucleotide',
    -id      => 'NM_174738',
    -rettype => 'gb',
    -retmode => 'text',
);

# Download the record
my $gb_data = $factory->get_Response->decoded_content;

# Convert the downloaded text into a filehandle
my $stringio = IO::String->new($gb_data);

# Read the GenBank record
my $seqio = Bio::SeqIO->new(
    -fh     => $stringio,
    -format => 'genbank'
);

my $seq = $seqio->next_seq;

# Print required information
print "Accession : ", $seq->accession_number, "\n";
print "Description : ", $seq->desc, "\n";
print "Length : ", $seq->length, " bp\n";
