# Part I: Basic R Programming
# Question 1: Gene Expression Values

# Create a vector containing gene expression values
expression_values <- c(120, 135, 98, 145, 160, 178, 155, 132)

# Display the vector
expression_values

# Check the number of values
length(expression_values)

# a) Calculate the mean expression value
mean_expression <- mean(expression_values)
mean_expression

# b) Calculate the median expression value
median_expression <- median(expression_values)
median_expression

# c) Calculate the standard deviation
sd_expression <- sd(expression_values)
sd_expression

# d) Calculate the maximum and minimum values
maximum_expression <- max(expression_values)
minimum_expression <- min(expression_values)

maximum_expression
minimum_expression

# e) Create a bar plot of the expression values
barplot(
  expression_values,
  main = "Gene Expression Values",
  xlab = "Gene",
  ylab = "Expression Level"
)
# ============================================================
# Question 2: Gene Expression Data Frame
# ============================================================

# Create the data frame
gene_expression <- data.frame(
  Gene = c("TP53", "BRCA1", "MYC", "EGFR"),
  Sample1 = c(120, 100, 200, 180),
  Sample2 = c(150, 125, 260, 240)
)

# Display the complete data frame
gene_expression

# a) Display the first two rows
head(gene_expression, 2)

# b) Calculate the average expression for each gene
gene_expression$Average_Expression <-
  rowMeans(gene_expression[, c("Sample1", "Sample2")])

# Display the data frame with average expression
gene_expression

# c) Identify the gene with the highest expression in Sample2
highest_sample2_gene <-
  gene_expression$Gene[which.max(gene_expression$Sample2)]

highest_sample2_gene
# ============================================================
# Part II: Sequence Analysis Using Biostrings
# Question 3
# ============================================================

# Load the Biostrings package
library(Biostrings)

setwd("/home/keti/Documents/R_Assignment")
getwd()
file.exists("genes.fasta")

# a) Read the FASTA file into R
sequences <- readDNAStringSet("genes.fasta")

# Display the sequences
sequences

# Display sequence names
names(sequences)

# b) Determine the length of each sequence
sequence_lengths <- width(sequences)
sequence_lengths

# c) Calculate nucleotide frequencies
nucleotide_frequencies <- alphabetFrequency(
  sequences,
  baseOnly = TRUE
)

nucleotide_frequencies[, c("A", "C", "G", "T")]

# d) Calculate GC content (%)
gc_content <- (
  nucleotide_frequencies[, "G"] +
    nucleotide_frequencies[, "C"]
) / width(sequences) * 100

gc_content <- round(gc_content, 2)

# Create a summary table
sequence_summary <- data.frame(
  Gene = names(sequences),
  Length = width(sequences),
  GC_Content = gc_content
)

sequence_summary

# e) Identify all sequences with the highest GC content
highest_gc_genes <- names(sequences)[
  gc_content == max(gc_content)
]

highest_gc_genes

# Display the highest GC content
max(gc_content)
# ============================================================
# Part III: Gene Expression Analysis
# Question 4
# ============================================================

# a) Import the dataset
gene_expression <- read.csv("gene_expression.csv")

# Display the imported dataset
gene_expression

# b) Calculate Fold Change
# Formula: Fold Change = Treatment / Control
gene_expression$Fold_Change <-
  gene_expression$Treatment /
  gene_expression$Control

# Round Fold Change to two decimal places
gene_expression$Fold_Change <-
  round(gene_expression$Fold_Change, 2)

# Display the data with Fold Change
gene_expression

# c) Identify genes with Fold Change > 2
genes_fc_greater_than_2 <-
  gene_expression[
    gene_expression$Fold_Change > 2,
  ]

# Display genes with Fold Change > 2
genes_fc_greater_than_2

# d) Create a bar chart showing Fold Changes
barplot(
  gene_expression$Fold_Change,
  names.arg = gene_expression$Gene,
  main = "Gene Expression Fold Changes",
  xlab = "Gene",
  ylab = "Fold Change",
  ylim = c(
    0,
    max(gene_expression$Fold_Change) + 1
  )
)

# e) Identify the genes that appear differentially expressed
# using the criterion Fold Change > 2
differentially_expressed_genes <-
  gene_expression$Gene[
    gene_expression$Fold_Change > 2
  ]

differentially_expressed_genes