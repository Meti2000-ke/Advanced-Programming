#!/usr/bin/perl

use strict;
use warnings;

my %gene_length = (
    "EDN3"  => 2156,
    "PDE5A" => 3245,
    "DNAH7" => 8540
);

print "EDN3 length = $gene_length{EDN3}\n";
