use strict;
use warnings;
use Bio::SeqIO;

my $seqio = Bio::SeqIO->new(
    -file   => "exercise8.fasta",
    -format => "fasta"
);

while (my $seq = $seqio->next_seq) {
    my $id = $seq->id;
    my $length = $seq->length;
    my $first10 = substr($seq->seq, 0, 10);

    print "ID: $id\n";
    print "Length: $length\n";
    print "First 10 bp: $first10\n\n";
}
