#!/usr/bin/perl

use strict;
use warnings;

my $sequence = "ATCGAATTCGGGGAATTCATC";
my $site = "GAATTC";

while ($sequence =~ /$site/g) {
    my $position = pos($sequence) - length($site) + 1;
    print "EcoRI found at position $position\n";
}
