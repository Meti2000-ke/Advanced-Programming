#!/usr/bin/perl

# Store information in variables
$gene_name = "EDN3";
$chromosome = "chr13";
$length = 2156;

# Print the values
print "Gene: $gene_name\n";
print "Chromosome: $chromosome\n";
print "Length: $length\n";
