#!/usr/bin/perl

use strict;
use warnings;
use Bio::SearchIO;

my $searchio = Bio::SearchIO->new(
    -format => 'blast',
    -file   => 'blast_full.out'
);

while (my $result = $searchio->next_result) {

    while (my $hit = $result->next_hit) {

        # Skip the query sequence itself
        next if $hit->name eq "Query";

        my $hsp = $hit->next_hsp;

        if ($hsp) {
            print "Hit : ", $hit->name, "\n";
            print "E-value : ", $hsp->evalue, "\n";
            print "Identity : ", $hsp->percent_identity, "\n";
        }

        last;
    }
}
