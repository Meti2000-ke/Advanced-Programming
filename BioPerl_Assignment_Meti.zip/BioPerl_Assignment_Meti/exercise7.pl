#!/usr/bin/perl

use strict;
use warnings;

open(my $fh, "<", "genes.fasta") or die "Cannot open file!\n";

my $id = "";

while (my $line = <$fh>) {

    chomp $line;

    if ($line =~ /^>/) {

        $id = substr($line, 1);

    } else {

        my $length = length($line);

        print "ID: $id\n";
        print "Length: $length\n\n";
    }
}

close($fh);
