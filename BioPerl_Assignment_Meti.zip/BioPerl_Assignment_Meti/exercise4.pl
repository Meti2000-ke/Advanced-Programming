#!/usr/bin/perl

use strict;
use warnings;

my $seq = "ATGCGCGATATCGCGAT";

# Sequence length
my $length = length($seq);

# Count G bases
my $g_count = ($seq =~ tr/G/G/);

# Count C bases
my $c_count = ($seq =~ tr/C/C/);

# Total GC count
my $gc_count = $g_count + $c_count;

# GC percentage
my $gc_percent = ($gc_count / $length) * 100;

printf "Length: %d\n", $length;
printf "GC Count: %d\n", $gc_count;
printf "GC%%: %.2f\n", $gc_percent;
