#!/usr/bin/perl

use strict;
use warnings;

my $seq = "ATGCCGAAT";

# Create complement
$seq =~ tr/ATGC/TACG/;

# Reverse the complemented sequence
my $revcomp = reverse($seq);

print "$revcomp\n";
